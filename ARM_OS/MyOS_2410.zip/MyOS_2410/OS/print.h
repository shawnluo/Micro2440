// Version 0.0.0.1
// Author Liyong-Zou
// Create date 2012-07-22
// Init File


/*** V0.0.0.1 ***/

#ifndef _PRINT_H
#define _PRINT_H
extern int sprintf_s(char *str, unsigned int size, const char *fmt, ...);
#endif
