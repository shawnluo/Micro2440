
#ifndef _SYSCALL_H
#define _SYSCALL_H

//extern int test_syscall(void);

#endif
