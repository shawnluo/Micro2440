#ifndef _TEST_H
#define _TEST_H

extern void test(void);

#endif
