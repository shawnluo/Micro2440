// Version 0.0.0.1
// Author Liyong-Zou
// Create Date 2012-07-20
// Init file

/* Date 2012-07-20
/* Author Liyong-Zou
/* Add function init_clock
*/
#ifndef _CLOCK_H
#define _CLOCK_H

#define PHYSICAL_TCFG0		(0x51000000)
#define PHYSICAL_TCFG1		(0x51000004)
#define PHYSICAL_TCON		(0x51000008)
#define PHYSICAL_TCNTB		(0x5100003c)

extern void init_clock(void);

#endif
