// Version 0.0.0.1
// Author Liyong-Zou
// Create Date 2012-07-20
// Init file


/*** V0.0.0.1 ***/

/* Date 2012-07-20
/* Author Liyong-Zou
/* Add defined UNCON0
*/

/* Date 2012-07-22
/* Author Liyong-Zou
/* Remove define UNCON0
/* Add function: display
*/

#ifndef _MYOS_H
#define _MYOS_H

#define _DEBUG

#include "print.h"

/* remove @ 2012-07-22
#ifndef UNCON0
#define UNCON0 ((volatile unsigned int *)0x50000020)
#endif
*/

#define NULL ((void *) 0)

extern void display(const char *msg);

typedef enum {
	false = 0,
	true
} bool;
bool g_b_start_mmu;

#endif
