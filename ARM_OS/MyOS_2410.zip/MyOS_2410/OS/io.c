// Version 0.0.0.1
// Author Liyong-Zou
// Create Date 2012-07-20
// Init file

/* Date 2012-07-20
/* Author Liyong-Zou
/* Init function init_io
*/

#include "io.h"
#include "MyOS.h"

void init_io(void)
{
	display("Initializing io\n");
}
