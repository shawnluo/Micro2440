// Version 0.0.0.1
// Author Liyong-Zou
// Create date 2012-07-19
// Init File

/*** V0.0.0.1 ***/

/* Date 2012-07-19
/* Author Liyong-Zou
/* Add function plat_boot
*/

#include "MyOS.h"
#include "mmu.h"
#include "clock.h"
#include "memory.h"
#include "irq.h"
#include "io.h"
#include "boot_start.h"
#include "storage.h"
#include "fs.h"
#include "proc.h"
#include "test.h"

typedef void (*init_func)(void);

static init_func init[] = {
	init_mmu,
	init_task,
	init_clock,
	init_memory,
	init_sd,
	init_fs,
	init_irq,
	init_io,
	0
};

void plat_boot(void)
{
	g_b_start_mmu = false;
	display("plat boot\n");

	int i = 0;
	for(i = 0; 0 != init[i]; i++) {
		init[i]();
	}

	boot_start();
/*
	// test memory page
	char *p1, *p2, *p3, *p4;
	while(1) {
		p1 = get_free_pages(8);
		if(p1) {
			sprintf_s(p1, (1 << 10) << 2, "alloc pages address: %x\n", p1);
			display(p1);
		} else {
			display("alloc mem fail!\n");
		}
	p2 = get_free_pages(8);
	sprintf_s(p2, (1 << 10) << 2, "alloc pages address: %x\n", p2);
	display(p2);
	put_free_pages(p1);
	put_free_pages(p2);
	}
*/
	test();
	while(1);
}

