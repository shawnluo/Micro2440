// Version 0.0.0.1
// Author Liyong-Zou
// Create Date 2012-07-22
// Init file


/*** V0.0.0.1 ***/

/* Date 2012-07-22
/* Author Liyong-Zou
/* Add defined UNCON0_UN_MMU, UNCON0_MMU
/* Implement function: dispaly
*/

#include "MyOS.h"

#define UNCON0_UN_MMU ((volatile unsigned int *)0x50000020)
#define UNCON0_START_MMU ((volatile unsigned int *)0xd0000020)

//g_b_start_mmu = false;
void display(const char *msg)
{
	volatile unsigned int *uncon0;
	if(g_b_start_mmu) {
		uncon0 = UNCON0_START_MMU;
	}
	else {
		uncon0 = UNCON0_UN_MMU;
	}

	while(*msg) {
		*uncon0 = *msg++;
	}
}
