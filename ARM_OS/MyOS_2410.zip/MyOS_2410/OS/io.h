// Version 0.0.0.1
// Author Liyong-Zou
// Create Date 2012-07-20
// Init file

/* Date 2012-07-20
/* Author Liyong-Zou
/* Add function init_io
*/
#ifndef _IO_H
#define _IO_H

extern void init_io(void);

#endif
