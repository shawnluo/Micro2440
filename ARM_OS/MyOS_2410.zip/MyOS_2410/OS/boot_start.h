// Version 0.0.0.1
// Author Liyong-Zou
// Create Date 2012-07-21
// Init file

/* Date 2012-07-21
/* Author Liyong-Zou
/* Add function init_clock
*/
#ifndef _BOOT_START_H
#define _BOOT_START_H

extern void boot_start(void);

#endif
