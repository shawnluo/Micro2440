// Version 0.0.0.1
// Author Liyong-Zou
// Create Date 2012-07-20
// Init file

/* Date 2012-07-20
/* Author Liyong-Zou
/* Init function init_memory
*/

/* Date 2012-07-30
/* Author Liyong-Zou
/* Implement function get_pages_from_list
*/

/* Date 2012-07-31
/* Author Liyong-Zou
/* Implement function put_pages_to_list
*/

/* Date 2012-08-01
/* Author Liyong-Zou
/* Implement slab
*/

/* Date 2012-08-03
/* Author Liyong-Zou
/* Implement kmalloc
*/

#include "memory.h"
#include "MyOS.h"
#include "doubly_linked_list.h"

static void init_page_map(void);
static void kmalloc_init(void);

#define PAGE_SHIFT		(12)
#define PAGE_SIZE		(1<<PAGE_SHIFT)
#define PAGE_MASK		(~(PAGE_SIZE - 1))

#define KERNEL_MEM_END		(_MEM_END)

// KERNEL_PAGING --> 被分页内存
#define KERNEL_PAGING_START	((_MEM_START + (~PAGE_MASK)) & (PAGE_MASK))
#define KERNEL_PAGING_END	(KERNEL_PAGING_START + \
				(KERNEL_MEM_END - KERNEL_PAGING_START) / (PAGE_SIZE + sizeof(struct page)) * PAGE_SIZE)

// KERNEL_PAGE --> 页内存
#define KERNEL_PAGE_NUM		((KERNEL_PAGING_END - KERNEL_PAGING_START) / PAGE_SIZE)
#define KERNEL_PAGE_END		(_MEM_END)
#define KERNEL_PAGE_START	(KERNEL_PAGE_END - KERNEL_PAGE_NUM * sizeof(struct page))

#define PAGE_AVAILABLE		0x00
#define PAGE_DIRTY		0x01
#define PAGE_PROTECT		0x02
#define PAGE_BUDDY_BUSY		0x04
#define PAGE_IN_CACHE		0x08

#define MAX_BUDDY_PAGE_NUM	(9)
#define AVERAGE_PAGE_NUM_PER_BUDDY\
				(KERNEL_PAGE_NUM / MAX_BUDDY_PAGE_NUM)
#define PAGE_NUM_FOR_MAX_BUDDY	((1 << MAX_BUDDY_PAGE_NUM - 1) - 1)

#define BUDDY_END(x, order)	((x) + (1 << (order)) - 1)
#define NEXT_BUDDY_START(x, order) \
				((x) + (1 << (order)))
#define PREV_BUDDY_START(x, order) \
				((x) - (1 << (order)))

/***********************Buddy***************************/
struct page {
	unsigned int vaddr;
	unsigned int flags;
	int order;
	struct kmem_cache *cachep;
	struct list_node list;
};
/*
struct kmem_cache {
	unsigned int obj_size;
	unsigned int max_block_num;
	unsigned int obj_nr;
	int page_order;
	unsigned int flags;
	struct page *head_page;
	struct page *end_page;
	void *nf_block;
};
*/
struct list_head page_buddy[MAX_BUDDY_PAGE_NUM];

static void init_page_buddy(void)
{
	int i;
	for(i = 0; i<MAX_BUDDY_PAGE_NUM; i++) {
		INIT_LIST_HEAD(&page_buddy[i]);
	}
}

void init_page_map(void)
{
#ifdef _DEBUG
	display("\t>init_page_map\n");
#endif
	int i;
	struct page *pg = (struct page *)KERNEL_PAGE_START;
	init_page_buddy();

	// Init every page
	for(i = 0; i < KERNEL_PAGE_NUM; pg++, i++) {
		pg->vaddr = KERNEL_PAGING_START + i * PAGE_SIZE;
		pg->flags = PAGE_AVAILABLE;

		//整段的页
		if(i < (KERNEL_PAGE_NUM & (~PAGE_NUM_FOR_MAX_BUDDY))) {
			if(0 == (i & PAGE_NUM_FOR_MAX_BUDDY)) {
				pg->order = MAX_BUDDY_PAGE_NUM - 1;
			} else {
				pg->order = -1;
			}
			list_add_tail(&(pg->list), &page_buddy[MAX_BUDDY_PAGE_NUM - 1]);
		} else {
			pg->order = 0;
			list_add_tail(&(pg->list), &page_buddy[0]);
		}
	}
}

void init_memory(void)
{
#ifdef _DEBUG
	display("Initializing memory\n");
#endif
	init_page_map();
	kmalloc_init();
}

struct page *get_pages_from_list(int order)
{
	char sz[128];
	sprintf_s(sz, 128, "\t>get_pages_from_list in order %d\n", order);
	display(sz);

	struct page *pg = NULL;

	if(order < 0 || order >= MAX_BUDDY_PAGE_NUM) return NULL;

	if(list_empty(&page_buddy[order])) {
		if((MAX_BUDDY_PAGE_NUM - 1) == order) {
			return NULL;
		}
		pg = get_pages_from_list(order + 1);
		if(!pg) return pg;
		page_buddy[order].next = &(pg->list);
		pg->list.prev = &(page_buddy[order]);
		page_buddy[order].prev = &(BUDDY_END(pg, order + 1)->list);
		BUDDY_END(pg, order + 1)->list.next = &(page_buddy[order]);
		pg->order = order;
		NEXT_BUDDY_START(pg, order)->order = order;
	}

	pg = list_entry(page_buddy[order].next, struct page, list);
/*
	page_buddy[order].next = page_buddy[order].next->next;
	page_buddy[order].next->prev = &page_buddy[order];
*/
	list_remove_chain(&(pg->list), &(BUDDY_END(pg, order)->list));

	pg->flags |= PAGE_BUDDY_BUSY;
	return pg;
}

void put_pages_to_list(struct page *pg)
{
	char sz[128];
	sprintf_s(sz, 128, "\t>put_pages_to_list in order %d\n", pg->order);
	display(sz);
	const int order = pg->order;
	struct page *tprev = NULL;
	struct page *tnext = NULL;

	if(!(pg->flags & PAGE_BUDDY_BUSY)) {
		return;
	}

	pg->flags &= ~PAGE_BUDDY_BUSY;

	if(MAX_BUDDY_PAGE_NUM - 1 != order) {
		tprev = PREV_BUDDY_START(pg, order);
		if(tprev < (struct page *)KERNEL_PAGE_START) {
			tprev = NULL;
		}

		tnext = NEXT_BUDDY_START(pg, order);
		if(NEXT_BUDDY_START(tnext, order) > (struct page *)KERNEL_PAGE_END) {
			tnext = NULL;
		}

		if(tprev && (order == tprev->order) && (!(tprev->flags & PAGE_BUDDY_BUSY))) {
			tprev->order = order + 1;
			pg->order = -1;
			list_remove_chain(&(tprev->list), &(BUDDY_END(tprev, order)->list));
			pg->list.prev = &(BUDDY_END(tprev, order)->list);
			BUDDY_END(tprev, order)->list.next = &(pg->list);
			tprev->flags |= PAGE_BUDDY_BUSY;
			put_pages_to_list(tprev);
			return;
		} else if(tnext && (order == tnext->order) && (!(tnext->flags & PAGE_BUDDY_BUSY))) {
			pg->order = order + 1;
			tnext->order = -1;
			list_remove_chain(&(tnext->list), &(BUDDY_END(tnext, order)->list));
			BUDDY_END(pg, order)->list.next = &(tnext->list);
			tnext->list.prev = &(BUDDY_END(pg, order)->list);
			pg->flags |= PAGE_BUDDY_BUSY;
			put_pages_to_list(pg);
			return;
		}
	}

	list_add_chain(&(pg->list), &(BUDDY_END(pg, order)->list), &(page_buddy[order]));
}

struct page *virt_to_page(unsigned int addr)
{
	unsigned int i = (addr - KERNEL_PAGING_START) >> PAGE_SHIFT;

	if(i > KERNEL_PAGE_NUM) return NULL;
	return (struct page *)KERNEL_PAGE_START + i;
}

void *page_address(struct page *pg)
{
	return (void *)(pg->vaddr);
}

struct page *alloc_pages(int order)
{
	struct page *pg = NULL;
	int i = 0;

	pg = get_pages_from_list(order);
	if(pg) {
		for(i = 0; i<(1 << order); i++) {
			(pg + i)->flags |= PAGE_DIRTY;
		}
	}

	return pg;
}

void free_pages(struct page *pg)
{
	int i = 0;

	for(i = 0; i < (1 << pg->order); i++) {
		(pg + i)->flags &= ~PAGE_DIRTY;
	}

	put_pages_to_list(pg);
}

void *get_free_pages(int order)
{
	struct page *pg = NULL;

	pg = alloc_pages(order);

	if(!pg) return NULL;
	return page_address(pg);
}

void put_free_pages(void *addr)
{
	free_pages(virt_to_page((unsigned int)addr));
}


/**********************************Slab****************************************/

#define KMEM_CACHE_DEFAULT_ORDER	(0)
#define KMEM_CACHE_MAX_ORDER		(5)
#define KMEM_CACHE_SAVE_RATE		(90)
#define KMEM_CACHE_PERCENT		(100)
#define KMEM_CACHE_MAX_WAST		(PAGE_SIZE -  PAGE_SIZE * \
					KMEM_CACHE_SAVE_RATE / KMEM_CACHE_PERCENT)

static int find_right_order(unsigned int size)
{
	int order = KMEM_CACHE_DEFAULT_ORDER;

	for(order = KMEM_CACHE_DEFAULT_ORDER; order < KMEM_CACHE_MAX_ORDER; order++) {
		if(size <= KMEM_CACHE_MAX_WAST * (1 << order)) {
			return order;
		}
	}

	if(size > (PAGE_SIZE << order)) {
		return -1;
	}

	return order;
}

static int kmem_cache_line_object(void *head, unsigned int size, int order)
{
	void **p = (void **)head; //point to block's head where save next block's address
	char *next_block = (char *)head + size; //next block's address
	int i = 0;
	unsigned int slab_left_size = PAGE_SIZE * (1 << order);

	for(i = 0; slab_left_size > size; i++) {
		*p = next_block;
		p = (void **)next_block;
		next_block += size;
		slab_left_size -= size;
	}

	if(slab_left_size == size) {
		i++;
	}

	*((void **)((char *)head + size * (i - 1))) = NULL;

	return i;
}

struct kmem_cache *kmem_cache_create(struct kmem_cache *cache, unsigned int size, unsigned int flags)
{
#ifdef _DEBUG
	char msg[128];
	display("\t>kmem_cache_create\n");
#endif

	if(size < 4) return NULL;

	unsigned int block_num = 0;
	int order = find_right_order(size);
	
#ifdef _DEBUG
	sprintf_s(msg, 128, "\t>find_right_order: %d\n", order);
	display(msg);
#endif
	if(-1 == order) {
		return NULL;
	}

	if(NULL == (cache->head_page = alloc_pages(order))) {
		return NULL;
	}

	cache->nf_block = page_address(cache->head_page);
	cache->obj_size = size;
	//cache->obj_nr = kmem_cache_line_object(cache->nf_block, size, order);
	block_num = kmem_cache_line_object(cache->nf_block, size, order);
	cache->max_block_num = block_num;
	cache->obj_nr = block_num;
	cache->page_order = order;
	cache->flags = flags;
	cache->end_page = BUDDY_END(cache->head_page, order);
	cache->end_page->list.next = NULL;
#ifdef _DEBUG
	sprintf_s(msg, 128, "\t>cache->nf_block: %x\n", cache->nf_block);
	display(msg);
	sprintf_s(msg, 128, "\t>left blocks: %d\n", cache->obj_nr);
	display(msg);
#endif
	return cache;
}

void *kmem_cache_alloc(struct kmem_cache *cache)
{
#ifdef _DEBUG
	display("\t>kmem_cache_alloc\n");
#endif
	void *p = NULL;
	unsigned int add_block_num = 0; 
	struct page *pg = NULL;

	if(!cache) return NULL;

	if(!cache->obj_nr) {
		if(!(pg = alloc_pages(cache->page_order))) {
			return NULL;
		}
#ifdef _DEBUG
		display("\t>alloc new buddy\n");
#endif
		cache->nf_block = page_address(pg);
		//cache->obj_nr += kmem_cache_line_object(cache->nf_block, cache->obj_size, cache->page_order);
		add_block_num = kmem_cache_line_object(cache->nf_block, cache->obj_size, cache->page_order);
		cache->max_block_num += add_block_num;
		cache->obj_nr += add_block_num;
		pg->list.prev = &(cache->end_page->list);
		cache->end_page->list.next = &(pg->list);
		cache->end_page = BUDDY_END(pg, cache->page_order);
		cache->end_page->list.next = NULL;
	}

	p = cache->nf_block;
	cache->nf_block = *(void **)p;
	virt_to_page((unsigned int)p)->cachep = cache;
	cache->obj_nr--;
#ifdef _DEBUG
	char msg[128];
	sprintf_s(msg, 128, "\t>left blocks: %d\n", cache->obj_nr);
	display(msg);
#endif
	return p;
}

void kmem_cache_free(void *objp)
{
#ifdef _DEBUG
	display("\t>kmem_cache_free\n");
#endif
	struct kmem_cache *cache = virt_to_page((unsigned int)objp)->cachep;
	*(void **)objp = cache->nf_block;
	cache->nf_block = objp;
	cache->obj_nr++;
#ifdef _DEBUG
	char msg[128];
	sprintf_s(msg, 128, "\t>left blocks: %d\n", cache->obj_nr);
	display(msg);
#endif
}

void kmem_cache_destory(struct kmem_cache *cache)
{
#ifdef _DEBUG
	char msg[128];
	display("\t>kmem_cache_destory\n");
#endif
	struct list_node *list = NULL;
	struct page *pg = cache->head_page;

	if(!cache) return;

	while(1) {
		list = BUDDY_END(pg, cache->page_order)->list.next;
#ifdef _DEBUG
		sprintf_s(msg, 128, "\t>Free address: %x\n", page_address(pg));
		display(msg);
#endif
		free_pages(pg);

		if(list) {
			pg = list_entry(list, struct page, list);
		} else {
			cache->obj_size = 0;
			cache->max_block_num = 0;
			cache->obj_nr = 0;
			cache->page_order = -1 ;
			cache->flags = 0;
			cache->head_page = NULL;
			cache->end_page = NULL;
			cache->nf_block = NULL;
			return;
		}
	}
}

/**************************************kmalloc*********************************************/
#define KMALLOC_BASE_SHIFT		(5)
#define KMALLOC_MAX_SIZE		(0x10000)
#define KMALLOC_MINIMAL_SIZE_BIAS	(1 << (KMALLOC_BASE_SHIFT))
#define KMALLOC_CACHE_SIZE		(KMALLOC_MAX_SIZE / KMALLOC_MINIMAL_SIZE_BIAS)
#define kmalloc_cache_size_to_index(size) \
					((size - 1) >> (KMALLOC_BASE_SHIFT))

struct kmem_cache kmalloc_cache[KMALLOC_CACHE_SIZE];

void kmalloc_init(void)
{
#ifdef _DEBUG
	display("\t>kmalloc_init\n");
#endif
	int i = 0;

	for(i = 0; i < KMALLOC_CACHE_SIZE; i++) {
		kmalloc_cache[i].obj_size = 0;
		kmalloc_cache[i].max_block_num = 0;
		kmalloc_cache[i].obj_nr = 0;
		kmalloc_cache[i].page_order = -1;
		kmalloc_cache[i].flags = 0;
		kmalloc_cache[i].head_page = NULL;
		kmalloc_cache[i].end_page = NULL;
		kmalloc_cache[i].nf_block = NULL;
	}
}

void *kmalloc(unsigned int size)
{
#ifdef _DEBUG
	char msg[128];
	sprintf_s(msg, 128, "\t>kmalloc(%x)\n", size);
	display(msg);
#endif
	if(0 == size) return NULL;

	int index = kmalloc_cache_size_to_index(size);

	if(index >= KMALLOC_CACHE_SIZE) return NULL;

	if(0 == kmalloc_cache[index].max_block_num) {
		if(!(kmem_cache_create(&(kmalloc_cache[index]), \
			(index + 1)*KMALLOC_MINIMAL_SIZE_BIAS, 0))) {
#ifdef _DEBUG
			display("\t>kmem_cache_create fail\n");
#endif
			return NULL;
		}
	}

	return kmem_cache_alloc(&(kmalloc_cache[index]));
}

void kfree(void *addr)
{
#ifdef _DEBUG
	char msg[128];
	sprintf_s(msg, 128, "\t>kfree mem: %x\n", addr);
	display(msg);
#endif
	struct kmem_cache *cache = virt_to_page((unsigned int)addr)->cachep;

	kmem_cache_free(addr);

	if(cache->obj_nr == cache->max_block_num) {
		kmem_cache_destory(cache);
	}

}
