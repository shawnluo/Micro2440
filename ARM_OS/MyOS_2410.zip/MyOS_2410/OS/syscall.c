
#include "syscall.h"
#include "MyOS.h"

#define __NR_SYSCALL_BASE		0x0
#define __NR_TEST			(__NR_SYSCALL_BASE + 0)
#define __NR_SYS_CALL			(__NR_SYSCALL_BASE + 1)

//num -> num of param; args -> list of param
typedef int (*syscall_fn)(int num, int *args);

// num -> 系统调用编号; pnum -> num of param; parry -> list of param; ret -> return value
#define SYSCALL(num, pnum, parray, ret)	do{\
				asm volatile ( \
				  "stmfd sp!, {%3}\n" \
				  "stmfd sp!, {%2}\n" \
				  "sub sp, sp, #4\n" \
				  "SWI %1\n" \
				  "ldmfd sp!, {%0}\n" \
				  "add sp, sp, #8\n" \
				  :"=r"(ret) \
				  :"i" (num), "r" (pnum), "r" (parray) \
				  :"r2", "r3"\
				 ); \
				}while(0)


syscall_fn syscall_test(int pnum, int *parry)
{
	display("syscall_test\n");

	int i = 0;
	char msg[128];
	for(i = 0; i < pnum; i++) {
		sprintf_s(msg, 128, "\t>param %d: %d\n", i, parry[i]);
		display(msg);
	}
	return 0;
}
/*
int test_syscall(void)
{
	int arry[] = {1, 2, 3, 4, 5};
	int ret;
	SYSCALL(__NR_SYSCALL_BASE, sizeof(arry)/sizeof(int), arry, ret);

	char msg[128];
	sprintf_s(msg, 128, "\t>ret = %d\n", ret);
}
*/
syscall_fn syscall_table[] = {
	syscall_test,
	0
};

int sys_call_schedule(int index, int pnum, int *args)
{
	if(index < (sizeof(syscall_table)/sizeof(syscall_fn)) && syscall_table[index]) {
		return (syscall_table[index])(pnum, args);
	}

	return -1;
}
