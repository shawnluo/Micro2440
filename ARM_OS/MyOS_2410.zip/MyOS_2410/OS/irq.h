// Version 0.0.0.1
// Author Liyong-Zou
// Create Date 2012-07-20
// Init file

/* Date 2012-07-20
/* Author Liyong-Zou
/* Add function init_irq
*/
#ifndef _IRQ_H
#define _IRQ_H

extern void init_irq(void);

#endif
