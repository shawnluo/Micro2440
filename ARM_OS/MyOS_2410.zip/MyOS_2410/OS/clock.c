// Version 0.0.0.1
// Author Liyong-Zou
// Create Date 2012-07-20
// Init file

/* Date 2012-07-20
/* Author Liyong-Zou
/* Init function init_clock
*/

#include "clock.h"
#include "MyOS.h"
#include "mmu.h"
#include "interrupt.h"

#define TCFG0		(PHYSICAL_TCFG0 + VIR_IO_ADDR_OFFSET)
#define TCFG1		(PHYSICAL_TCFG1 + VIR_IO_ADDR_OFFSET)
#define TCON		(PHYSICAL_TCON + VIR_IO_ADDR_OFFSET)
#define TCNTB4		(PHYSICAL_TCNTB + VIR_IO_ADDR_OFFSET)

void init_clock(void)
{
	display("Initializing clock\n");

	*(volatile unsigned int *)TCFG0 |= 0x800;

	//start timer4
	*(volatile unsigned int *)TCON &= ~(7<<20);
	*(volatile unsigned int *)TCON |= (1<<22);
	*(volatile unsigned int *)TCON |= (1<<21);
	*(volatile unsigned int *)TCNTB4 = 100000;
	*(volatile unsigned int *)TCON |= (1<<20);
	*(volatile unsigned int *)TCON &= ~(1<<21);

	unmask_int(14);
	enable_irq();
}
