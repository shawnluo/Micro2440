#ifndef _FILESYSTEM_H
#define _FILESYSTEM_H

#include "storage.h"

#define MAX_SUPER_BLOCK		(8)
#define ROMFS			(0)

struct super_block;
struct inode {
	char *name;
	unsigned int flags;
	size_t dsize; //size of file
	unsigned int daddr;
	struct super_block *super;
};

struct super_block {
	//get inode by file's name
	struct inode *(*namei)(struct super_block *super, char *p);
	//get file data's address
	unsigned int (*get_daddr)(struct inode *);
	struct storage_device *device;
	char *name;
};

extern struct super_block *fs_type[];

extern void init_fs(void);

#endif
