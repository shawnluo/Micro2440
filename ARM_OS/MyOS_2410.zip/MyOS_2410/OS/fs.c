#include "MyOS.h"
#include "fs.h"
#include "string.h"

struct super_block *fs_type[MAX_SUPER_BLOCK];

int register_file_system(struct super_block *type, unsigned int id)
{
	if(fs_type[id]) {
		return -1;
	} else {
		fs_type[id] = type;
	}
	return 0;
}

/********************************romfs***************************************/
#define be32_to_le32(x)		(unsigned int)( \
					(((unsigned int)(x) & (unsigned int)0x000000ff) << 24) | \
					(((unsigned int)(x) & (unsigned int)0x0000ff00) << 8) | \
					(((unsigned int)(x) & (unsigned int)0x00ff0000) >> 8) | \
					(((unsigned int)(x) & (unsigned int)0xff000000) >> 24))
//romfs fs头信息
struct romfs_super_block {
	unsigned int word0;
	unsigned int word1;
	unsigned int size;
	unsigned int checksum;
	char name[0];
};

//romfs file头信息
struct romfs_inode {
	unsigned int next;
	unsigned int spec;
	unsigned int size;
	unsigned int checksum;
	char name[0];
};

struct super_block romfs_super_block;

#define ROMFS_MAX_FILE_NAME		(127)
#define ROMFS_NAME_ALIGN_SIZE		(16)
#define ROMFS_SUPER_UP_MARGIN		(16)
#define ROMFS_NAME_MASK			(~(ROMFS_NAME_ALIGN_SIZE - 1))
#define ROMFS_NEXT_MASK			0xfffffff0

#define romfs_get_first_file_header(p) \
					(((strlen(((struct romfs_inode *)p)->name) + \
					ROMFS_NAME_ALIGN_SIZE + \
					ROMFS_SUPER_UP_MARGIN) & \
					ROMFS_NAME_MASK))

#define romfs_get_file_data_offset(p, num) \
					((((num) + ROMFS_NAME_ALIGN_SIZE) & \
					ROMFS_NAME_MASK) + \
					ROMFS_SUPER_UP_MARGIN + (p))

static char *bmap(char *tmp, char *dir) {
	unsigned int n = 0;
	char *p = strchr(dir, '/');
	memset(tmp, 0, ROMFS_MAX_FILE_NAME + 1);
	if(!p) {
		strcpy(tmp, dir);
		return NULL;
	}
	n = p - dir;
	n = (n > ROMFS_MAX_FILE_NAME)?ROMFS_MAX_FILE_NAME : n;
	strncpy(tmp, dir, n);
	return p + 1;
}

static char *get_file_name(char *p, char *name) {
	int index = 0;
	for(; *p; p++) {
		if('/' == *p) {
			index = 0;
			continue;
		} else {
			name[index++] = *p;
		}
	}
	name[index] = '\0';
	return name;
}

struct inode *romfs_namei(struct super_block* block, char *dir)
{
#ifdef _DEBUG
	char msg[512];
	sprintf_s(msg, 512, "rmofs_namei(%s)\n", dir);
	display(msg);
#endif
	struct inode *finode = NULL;
	struct romfs_inode *p = NULL;
	unsigned int tmp = 0;
	unsigned int next = 0;
	unsigned int num = 0;
	char fname[ROMFS_MAX_FILE_NAME + 1];
	char name[ROMFS_MAX_FILE_NAME + 1];
	unsigned int max_p_size = ROMFS_MAX_FILE_NAME + 1 + sizeof(struct romfs_inode);
	
	get_file_name(dir, fname);
	if(NULL == (p = (struct romfs_inode *)kmalloc(max_p_size))) {
		return NULL;
	}

	dir = bmap(name, dir);
	if(block->device->dout(block->device, p, 0, max_p_size)) {
		kfree(p);
		p = NULL;
		return NULL;
	}

	next = romfs_get_first_file_header(p);
	next = be32_to_le32(next);

	while(1) {
		tmp = (be32_to_le32(next)) & ROMFS_NEXT_MASK;
		if(0 == tmp || tmp > block->device->storage_size) {
			kfree(p);
			p = NULL;
			return NULL;
		}

		if(block->device->dout(block->device, p, tmp, max_p_size)) {
			kfree(p);
			p = NULL;
			return NULL;
		}
#ifdef _DEBUG
display("\t>find file: ");
display(p->name);
display("\n");
#endif
		if(strcmp(p->name, name)) {
			next = p->next;
			continue;
		} else if(NULL != dir){
			dir = bmap(name, dir);
			next = p->spec;
			continue;
		} else {
			if(NULL == (finode = (struct inode *)kmalloc(sizeof(struct inode)))) {
				kfree(p);
				p = NULL;
				return NULL;
			}

			num = strlen(p->name) + 1;
			if(NULL == (finode->name = (char *)kmalloc(num))) {
				kfree(p); p = NULL;
				kfree(finode); finode = NULL;
				return NULL;
			}

			strcpy(finode->name, p->name);
			finode->dsize = be32_to_le32(p->size);
			finode->daddr = tmp;
			finode->super = &romfs_super_block;
			kfree(p); p = NULL;
			return finode;
		}
	}
}

unsigned int romfs_get_daddr(struct inode *node)
{
#ifdef _DEBUG
	char msg[128];
	sprintf_s(msg, 128, "\t>romfs_get_daddr node->daddr: %x\n", node->daddr);
	display(msg);
#endif
	return romfs_get_file_data_offset(node->daddr, strlen(node->name));
}

struct super_block romfs_super_block = {
	.get_daddr = romfs_get_daddr,
	.namei = romfs_namei,
	.name = "romfs",
};

void init_fs(void)
{
#ifdef _DEBUG
	display("Initialiting file system\n");
#endif
	int ret = 0;
	ret = register_file_system(&romfs_super_block, ROMFS);
	romfs_super_block.device = storage[RAMDISK];
}
