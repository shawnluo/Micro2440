// Version 0.0.0.1
// Author Liyong-Zou
// Create Date 2012-07-20
// Init file

/* Date 2012-07-20
/* Author Liyong-Zou
/* Add function init_memory
*/

/* Date 2012-07-31
/* Author Liyong-Zou
/* Add function get_free_pages, put_free_pages
*/

#ifndef _MEMORY_H
#define _MEMORY_H

//user memory start
#define _MEM_END	0x30700000
//user memory end
#define _MEM_START	0x300f0000

struct kmem_cache {
	unsigned int obj_size;
	unsigned int max_block_num;
	unsigned int obj_nr;
	int page_order;
	unsigned int flags;
	struct page *head_page;
	struct page *end_page;
	void *nf_block;
};

extern void init_memory(void);

extern void *get_free_pages(int order);

extern void put_free_pages(void *addr);

extern struct kmem_cache *kmem_cache_create(struct kmem_cache *cache, unsigned int size, unsigned int flags);

extern void *kmem_cache_alloc(struct kmem_cache *cache);

extern void kmem_cache_free(void *objp);

extern void kmem_cache_destory(struct kmem_cache *cache);

#endif
