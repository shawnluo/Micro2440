// Version 0.0.0.1
// Author Liyong-Zou
// Create Date 2012-08-04
// Init file

#ifndef _STORAGE_H
#define _STORAGE_H

#define MAX_STORAGE_DEVICE		(2)
#define RAMDISK				(0)

typedef unsigned int size_t;
struct storage_device {
	unsigned int start_pos; //storage device's physical address
	size_t sector_size; //minimal store block size of storage device
	size_t storage_size; //total size of storage device
	unsigned int sn;
	int (*dout)(struct storage_device *sd, void *dest, unsigned int bias, size_t size);
	int (*din)(struct storage_device *sd, void *dest, unsigned int bias, size_t size);
	void (*device_init)(void);
};

extern struct storage_device *storage[MAX_STORAGE_DEVICE];
//extern int register_storage_device(struct storage_device *sd);
extern void init_sd(void);

#endif
