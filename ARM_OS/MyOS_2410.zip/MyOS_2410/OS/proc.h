

#ifndef _PROC_H
#define _PROC_H

extern init_task(void);

extern int do_fork(int (*f)(void *), void *args);

#endif
