// Version 0.0.0.1
// Author Liyong-Zou
// Create Date 2012-07-28
// Init file

#ifndef _DOUBLY_LINKED_LIST_H
#define _DOUBLY_LINKED_LIST_H

struct list_node {
	struct list_node *prev;
	struct list_node *next;
};

#define list_head list_node

inline void INIT_LIST_HEAD (struct list_head *list)
{
	list->prev = list;
	list->next = list;
}

inline void __list_add(struct list_node *new_list, struct list_node *prev, struct list_node *next)
{
	prev->next = new_list;
	new_list->prev = prev;
	new_list->next = next;
	next->prev = new_list;
}

inline void list_add(struct list_node *new_list, struct list_head *head)
{
	__list_add(new_list, head, head->next);
}

inline void list_add_tail(struct list_node *new_list, struct list_head *head)
{
	__list_add(new_list, head->prev, head);
}

inline void __list_del(struct list_node *prev, struct list_node *next)
{
	prev->next = next;
	next->prev = prev;
}

inline void list_del(struct list_node *entry)
{
	__list_del(entry->prev, entry->next);
	entry->prev = NULL;
	entry->next = NULL;
}

inline void list_remove_chain(struct list_node *ch, struct list_node *ct)
{
	ch->prev->next = ct->next;
	ct->next->prev = ch->prev;
	ch->prev = NULL;
	ct->next = NULL;
}

inline void list_add_chain(struct list_node *ch, struct list_node *ct, struct list_head *head)
{
	ch->prev = head;
	ct->next = head->next;
	head->next->prev = ct;
	head->next = ch;
}

inline void list_add_chain_tail(struct list_node *ch, struct list_node *ct, struct list_head *head)
{
	ch->prev = head->prev;
	ct->next = head;
	head->prev->next = ch;
	head->prev = ct;
}

inline int list_empty(const struct list_head *head)
{
	return head->next == head;
}

/*get member'offset in struct(TYPE)*/
#define offset_of(TYPE, member) ((unsigned int) &((TYPE *)0)->member)

#define container_of(ptr, type, member) ({\
	const typeof(((type *)0)->member) *__mptr = (ptr);\
	(type *)(((unsigned int) __mptr) - offset_of(type, member));})

#define list_entry(ptr, type, member) container_of(ptr, type, member)

#define list_for_each(pos, head)\
	for(pos = (head)->next; pos != (head); pos = pos->next)

#endif
