// Version 0.0.0.1
// Author Liyong-Zou
// Create Date 2012-07-19
// Init file

/* Date 2012-07-19
/* Author Liyong-Zou
/* Init function init_mmu
*/

/* Data 2012-07-21
/* Author Liyong-Zou
/* Implement Function: init_sys_mmu, gen_l1_pte and gen_l1_pte_addr
*/

/* Data 2012-07-22
/* Author Liyong-Zou
/* Implement Function: start_mmu
*/

#include "mmu.h"
#include "MyOS.h"

//PTE ==> page table entry
//gen ==> generator

#define PAGE_TABLE_L1_BASE_ADDR_MASK	(0xffffc000)
#define PTE_L1_SECTION_ADDR_BASE_MASK	(0xfff00000)
#define VIRT_TO_L1_INDEX(addr)		((addr & PTE_L1_SECTION_ADDR_BASE_MASK) >> 18)  //页表项偏移地址
#define PTE_L1_SECTION_NO_CACHE_AND_WB	(0x0 << 2)
#define PTE_L1_SECTION_DOMAIN_DEFAULT	(0x0 << 5)  //domian 0
#define PTE_AP_L1_SECTION_DEFAULT	(0x1 << 10)  //0b01
#define PTE_BITS_L1_SECTION		(0x2)  //段页表
#define L1_PTE_BASE_ADDR		(0x30700000)
/* 2012-07-25 move to mmu.h
#define PHYSICAL_MEM_ADDR		(0x30000000)
#define VIRTUAL_MEM_ADDR		(0x30000000)
#define MEM_MAP_SIZE			(0x800000)
#define PHYSICAL_IO_ADDR		(0x48000000)
#define VIRTUAL_IO_ADDR			(0xc8000000)
#define IO_MAP_SIZE			(0x18000000)
*/
/*Param:
/*	paddr --> _Input, physical address
/*
/*Return --> PTE
*/
static unsigned int gen_l1_pte(unsigned int paddr)
{
	return ((paddr & PTE_L1_SECTION_ADDR_BASE_MASK) | PTE_BITS_L1_SECTION);
}

/*Param:
/*	baddr --> _Input, pte base address
/*	vaddr --> _INput, virtual address
/*
/*Return --> pte address
*/
static unsigned int gen_l1_pte_addr(unsigned int baddr, unsigned int vaddr)
{
	return ((baddr & PAGE_TABLE_L1_BASE_ADDR_MASK) | VIRT_TO_L1_INDEX(vaddr));
}

static void init_sys_mmu(void)
{
	unsigned int pte = 0x0;
	unsigned int pte_addr = 0x0;
	int i = 0;

	//init pte for memory
	display("\t>Initializing mmu for memory\n");

	for(i = 0; i < 1/*(MEM_MAP_SIZE >> 20)*/; i++) {
		pte = gen_l1_pte(PHYSICAL_MEM_ADDR + (i << 20));
		pte |= PTE_AP_L1_SECTION_DEFAULT;
		pte |= PTE_L1_SECTION_DOMAIN_DEFAULT;
		pte |= PTE_L1_SECTION_NO_CACHE_AND_WB;

		pte_addr = gen_l1_pte_addr(L1_PTE_BASE_ADDR, VIRTUAL_VECTOR_ADDR + (i << 20));
		*(volatile unsigned int *) pte_addr = pte;
	}

	for(i = 0; i < (MEM_MAP_SIZE >> 20); i++) {
		// pte with default value
		pte = gen_l1_pte(PHYSICAL_MEM_ADDR + (i << 20));
		pte |= PTE_AP_L1_SECTION_DEFAULT;
		pte |= PTE_L1_SECTION_DOMAIN_DEFAULT;
		pte |= PTE_L1_SECTION_NO_CACHE_AND_WB;

		pte_addr = gen_l1_pte_addr(L1_PTE_BASE_ADDR, VIRTUAL_MEM_ADDR + (i << 20));
		*(volatile unsigned int *) pte_addr = pte;
	}

	//init pte for i/o
	display("\t>Initializing mmu for i/o\n");
	for(i = 0; i < (IO_MAP_SIZE >> 20); i++) {
		pte = gen_l1_pte(PHYSICAL_IO_ADDR + (i << 20));
		pte |= PTE_AP_L1_SECTION_DEFAULT;
		pte |= PTE_L1_SECTION_DOMAIN_DEFAULT;
		pte |= PTE_L1_SECTION_NO_CACHE_AND_WB;

		pte_addr = gen_l1_pte_addr(L1_PTE_BASE_ADDR, VIRTUAL_IO_ADDR + (i << 20));
		*(volatile unsigned int *) pte_addr = pte;
	}
}

void remap_l1(unsigned int paddr, unsigned int vaddr, int size)
{
	unsigned int pte;
	unsigned int pte_addr;
	int i = 0;

	for(i = 0; size > 0; size -= (1 << 20), i++) {
		pte = gen_l1_pte(paddr + (i << 20));
		pte |= PTE_AP_L1_SECTION_DEFAULT;
		pte |= PTE_L1_SECTION_DOMAIN_DEFAULT;
		pte |= PTE_L1_SECTION_NO_CACHE_AND_WB;

		pte_addr = gen_l1_pte_addr(L1_PTE_BASE_ADDR, vaddr + (i << 20));
		*(volatile unsigned int *) pte_addr = pte;
	}
}

void start_mmu(void)
{
	display("\t>Start mmu\n");
	const unsigned int l1_pte_baddr = L1_PTE_BASE_ADDR;

	asm (
		"mcr p15, 0, %0, c2, c0, 0\n"
		"mvn r0, #0\n"
		"mcr p15, 0, r0, c3, c0, 0\n"
		"mov r0, #0x1\n"
		"mcr p15, 0, r0, c1, c0, 0\n"
		"mov r0, r0\n"
		"mov r0, r0\n"
		"mov r0, r0\n"
		:
		: "r"(l1_pte_baddr)
		: "r0","r1"
	);
	g_b_start_mmu = true;
}

void init_mmu(void)
{
	display("Initializing mmu\n");
	init_sys_mmu();
	start_mmu();
}
