// Version 0.0.0.1
// Author Liyong-Zou
// Create Date 2012-08-04
// Init file

/* Date 2012-08-04
/* Author Liyong-Zou
/* Add fuction register_storage_device
*/

#include "MyOS.h"
#include "storage.h"
#include "mmu.h"

struct storage_device *storage[MAX_STORAGE_DEVICE];

int ramdisk_device_init(void);

int register_storage_device(struct storage_device *sd)
{
#ifdef _DEBUG
	char msg[128];
	sprintf_s(msg, 128, "\t>register_storage_device sn: %d\n", sd->sn);
	display(msg);
#endif
	if(storage[sd->sn]) {
		return -1;
	} else {
		storage[sd->sn] = sd;
	}

	return 0;
}

extern void init_sd(void)
{
#ifdef _DEBUG
	display("Initializing storage device\n");
#endif
	ramdisk_device_init();
}

/**********************************RAMDISK**************************************/
#define RAMDISK_SECTOR_SIZE			(512)
#define RAMDISK_SECTOR_MASK			(~(RAMDISK_SECTOR_SIZE - 1))
#define RAMDISK_SECTOR_OFFSET			(RAMDISK_SECTOR_SIZE - 1)

int ramdisk_out(struct storage_device *sd, void *dest, unsigned int bias, size_t size);
struct storage_device ramdisk_device = {
	.dout = ramdisk_out,
	.sector_size = RAMDISK_SECTOR_SIZE,
	.storage_size = 2<<20,
	.start_pos = 0x40800000,
	.sn = RAMDISK,
};

int ramdisk_out(struct storage_device *sd, void *dest, unsigned int bias, size_t size)
{
#ifdef _DEBUG
	char msg[128];
	sprintf_s(msg, 128, "\t>ramdisk_out(sd->start_pos:%x, dest, bias:%x, size:%d)\n",sd->start_pos, bias, size);
	display(msg);
#endif
	memcpy(dest, (void *)(bias + sd->start_pos), (unsigned int)size);
	return 0;
}

int ramdisk_device_init(void)
{
#ifdef _DEBUG
	display("\t>ramdisk_device_init\n");
#endif
	int ret;
	remap_l1(0x30800000, 0x40800000, 2 << 20);
	ret = register_storage_device(&ramdisk_device);
#ifdef _DEBUG
	if(-1 == ret) {
		display("\t>register_storage_device\n");
	}
#endif
	return ret;
}
