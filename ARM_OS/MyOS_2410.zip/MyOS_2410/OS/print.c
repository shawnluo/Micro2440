// Version 0.0.0.1
// Author Liyong-Zou
// Create date 2012-07-22
// Init File


/*** V0.0.0.1 ***/

#include "print.h"

/*I have a toolcahin working quite well: gcc-4.1.2 binutils-2.17, generic
arm softfloat supporting EABI. This works with kernel and userspace
well. Only on u-boot it fails at the final stage:

UNDEF_SYM=`arm-linux-objdump -x lib_generic/libgeneric.a
board/scb9328/libscb9328.a cpu/arm920t/libarm920t.a cpu/arm920t/imx/libimx.a
lib_arm/libarm.a fs/cramfs/libcramfs.a fs/fat/libfat.a fs/fdos/libfdos.a
fs/jffs2/libjffs2.a fs/reiserfs/libreiserfs.a fs/ext2/libext2fs.a net/libnet.a
disk/libdisk.a rtc/librtc.a dtt/libdtt.a drivers/libdrivers.a
drivers/nand/libnand.a drivers/nand_legacy/libnand_legacy.a
drivers/sk98lin/libsk98lin.a post/libpost.a post/cpu/libcpu.a
common/libcommon.a |sed  -n -e 's/.*\(__u_boot_cmd_.*\)/-u\1/p'|sort|uniq`;\
                cd /usr/src/u-boot/1.2.0 && arm-linux-ld -Bstatic -T
/usr/src/u-boot/1.2.0/board/scb9328/u-boot.lds -Ttext 0x08f00000  $UNDEF_SYM
cpu/arm920t/start.o \
                        --start-group lib_generic/libgeneric.a
board/scb9328/libscb9328.a cpu/arm920t/libarm920t.a cpu/arm920t/imx/libimx.a
lib_arm/libarm.a fs/cramfs/libcramfs.a fs/fat/libfat.a fs/fdos/libfdos.a
fs/jffs2/libjffs2.a fs/reiserfs/libreiserfs.a fs/ext2/libext2fs.a net/libnet.a
disk/libdisk.a rtc/librtc.a dtt/libdtt.a drivers/libdrivers.a
drivers/nand/libnand.a drivers/nand_legacy/libnand_legacy.a
drivers/sk98lin/libsk98lin.a post/libpost.a post/cpu/libcpu.a
common/libcommon.a --end-group -L
/usr/local/arm/gcc-4.1.2/lib/gcc/arm-linux-uclibcgnueabi/4.1.2 -lgcc \
                        -Map u-boot.map -o u-boot
/usr/local/arm/gcc-4.1.2/lib/gcc/arm-linux-uclibcgnueabi/4.1.2/libgcc.a(_dvmd_lnx.o):
In function `__div0':
/usr/src/br/buildroot-20070206/toolchain_build_arm_nofpu/gcc-4.1.2-20070128/gcc/config/arm/lib1funcs.asm:1000:
undefined reference to `raise'
make: *** [u-boot] Error 1

Well, compiling u-boot works fine with another arch (pxa xscale), only my arm9 
i.MX arch triggers a bug here. Does somebody have an advise or tip for
me how to fix this?

I digged around and added an (empty) raise() function to my u-boot, which
compiles fine. 

Kind Regards, Konsti*/
int __div0()
{
	return -1;
}

typedef char *va_list;
/*Get format size of n in strack*/
#define _INTSIZEOF(n)		((sizeof(n) + sizeof(int) - 1) & ~(sizeof(int) - 1))
/*Get next addr(after v) for ap*/
#define va_start(ap, v)		(ap = (va_list)&v + _INTSIZEOF(v))
/*Get the value that ap point to and set ap point to next value*/
#define va_arg(ap, t)		(*(t *)((ap += _INTSIZEOF(t)) - _INTSIZEOF(t)))
#define va_end(ap)		(ap = (va_list)0)

#define FORMAT_INIT_VALUE	0x00000000
#define INIT_FORMAT(f)		((f) &= FORMAT_INIT_VALUE)

#define FORMAT_TYPE_MASK	0xff00
#define FORMAT_TYPE_SIGN_BIT	0x0100
#define FORMAT_TYPE_NONE	0x000
#define FORMAT_TYPE_CHAR	0x100
#define FORMAT_TYPE_UCHAR	0x200
#define FORMAT_TYPE_SHORT	0x300
#define FORMAT_TYPE_USHORT	0x400
#define FORMAT_TYPE_INT		0x500
#define FORMAT_TYPE_UINT	0x600
#define FORMAT_TYPE_LONG	0x700
#define FORMAT_TYPE_ULONG	0x800
#define FORMAT_TYPE_STR		0xd00
#define FORMAT_TYPE_PTR		0x900
#define FORMAT_TYPE_SIZE_T	0xb00

#define FORMAT_TYPE(x)		((x) & FORMAT_TYPE_MASK)
/* set FORMAT_TYPE t to x */
#define SET_FORMAT_TYPE(x, t)	do {\
 (x) &= ~(FORMAT_TYPE_MASK);\
 (x) |= (t);\
} while(0)
#define FORMAT_SIGNED(x)	((x) & FORMAT_TYPE_SIGN_BIT)

#define FORMAT_FLAG_MASK	0xffff0000
#define FORMAT_FLAG_SPACE	0x10000
#define FORMAT_FLAG_ZEROPAD	0x20000
#define FORMAT_FLAG_LEFT	0x40000
#define FORMAT_FLAG_WIDTH	0x100000

#define FORMAT_FLAG(x)		((x) & FORMAT_FLAG_MASK)
#define SET_FORMAT_FLAG(x, f)	((x) |= (f))

#define FORMAT_BASE_MASK	0xff
#define FORMAT_BASE_O		0x08
#define FORMAT_BASE_X		0x10
#define FORMAT_BASE_D		0x0a
#define FORMAT_BASE_B		0x02

#define FORMAT_BASE(x)		((x) & FORMAT_BASE_MASK)
#define SET_FORMAT_BASE(x, b)	do {(x) &= ~FORMAT_BASE_MASK;\
 (x) |= (b);}\
while(0)
/*
#define do_div(n, base)		({\
 int __res;\
 __res = (unsigned int) n % (unsigned int) base;\
 n = (unsigned int) n / (unsigned int) base;\
 __res;\
})*/

inline int do_div(unsigned int *n, int base)
{
	int __res;
	__res = (unsigned int) *n % (unsigned int) base;
	*n = (unsigned int) *n / (unsigned int) base;
	return __res;
}


void *memcpy(void *dest, const void *src, int count)
{
	char *d = (char *) dest;
	const char *s = (const char *) src;
	while(count--) {
		*d++ = *s++;
	}

	return dest;
}

char *number(char *str, unsigned int size, int num, unsigned int flags)
{
	int i = 0;
	int sign = 0;
	char sz_num[64];
	char *end = str + size;
	unsigned int base = FORMAT_BASE(flags);
	const char digits[] = "0123456789abcdef";

	if(FORMAT_SIGNED(flags) && (num < 0)) {
		num = ~num + 1;  //get modulus for negative number
		sign = 1;
	}	

	do {
		//sz_num[i++] = digits[do_div(num, base)];
		sz_num[i++] = digits[do_div(&num, base)];
	} while(num/* && (i < sizeof(sz_num))*/);

	switch(base) {
	case FORMAT_BASE_O:
		sz_num[i++] = '0';
		break;

	case FORMAT_BASE_X:
		sz_num[i++] = 'x';
		sz_num[i++] = '0';
		break;

	case FORMAT_BASE_B:
		sz_num[i++] = 'b';
		sz_num[i++] = '0';
		break;
	}

	if(sign) {
		sz_num[i++] = '-';
	}

	while((i--) && (str < end)) {
		*str++ = sz_num[i];
	}

	return str;
}

int format_decode(const char *fmt, unsigned int *flags)
{
	const char *start = fmt;

	INIT_FORMAT(*flags);

	for(; *fmt; fmt++) {
		if('%' == *fmt) break;
	}

	if(fmt != start || !(*fmt)) {
		return (fmt - start);
	}

	fmt++;
	SET_FORMAT_BASE(*flags, FORMAT_BASE_D);
/*
	switch (*fmt) {
	case 'l':
		SET_FORMAT_FLAG(*flag, FORMAT_FLAG_WIDTH);
		break;

	default:
		break;
	}
*/
	switch (*fmt) {
	case 'c':
		SET_FORMAT_TYPE(*flags, FORMAT_TYPE_CHAR);
		break;

	case 's':
		SET_FORMAT_TYPE(*flags, FORMAT_TYPE_STR);
		break;

	case 'o':
	case 'O':
		SET_FORMAT_BASE(*flags, FORMAT_BASE_O);
		SET_FORMAT_TYPE(*flags, FORMAT_TYPE_UINT);
		break;

	case 'x':
	case 'X':
		SET_FORMAT_BASE(*flags, FORMAT_BASE_X);
		SET_FORMAT_TYPE(*flags, FORMAT_TYPE_UINT);
		break;

	case 'd':
	case 'i':
		SET_FORMAT_TYPE(*flags, FORMAT_TYPE_INT);
		break;

	case 'u':
		SET_FORMAT_TYPE(*flags, FORMAT_TYPE_UINT);
		break;

	default:
		break;
	}

	return (++fmt - start);
}

unsigned int vsnprintf_s(char *buf, unsigned int size, const char *fmt, va_list args)
{
	char *str = buf;
	char *end = buf + size;
/*
	if(end < buf) {
		end = (void*) -1;
		size = end - buf;
	}
*/
	while(*fmt) {
		if(str >= end) break;

		const char *old_fmt = fmt;

		unsigned int flags;
		INIT_FORMAT(flags);
		int read = format_decode(fmt, &flags);
		fmt += read;

		unsigned int format_type = FORMAT_TYPE(flags);

		if(FORMAT_TYPE_NONE == format_type) {
			int copy = read;
			if(copy > end - str) {
				copy = end - str;
			}
			memcpy(str, old_fmt, copy);
			str += read;
		} else if(flags & FORMAT_FLAG_WIDTH) {
			//nop;
		} else if(FORMAT_TYPE_CHAR == format_type) {
			char c = va_arg(args, char);
			*str++ = c;
		} else if(FORMAT_TYPE_STR == format_type) {
			char *s = va_arg(args, char *);
			while((str < end) && (*s)) {
				*str++ = *s++;
			}
		} else {
			int num = 0;
			if(format_type == FORMAT_TYPE_INT) {
				num = va_arg(args, int);
			} else if(format_type == FORMAT_TYPE_UINT) {
				num = va_arg(args, unsigned int);
			} else {
				num = va_arg(args, unsigned int);
			}
			str = number(str, end - str, num, flags);
		}
	}

	if(str < end) {
		*str = '\0';
	} else if(size > 0) {
		*(end - 1) = '\0';
	}

	return (str - buf);
}

int sprintf_s(char *str, unsigned int size, const char *fmt, ...)
{
	va_list args;
	va_start(args, fmt);

	unsigned int u = vsnprintf_s(str, size, fmt, args);

	va_end(args);
}
