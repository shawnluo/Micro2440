
#include "exec.h"
#include "fs.h"
#include "MyOS.h"

typedef unsigned int elf32_addr;
typedef unsigned int elf32_word;
typedef signed int elf32_sword;
typedef unsigned short elf32_half;
typedef unsigned int elf32_off;

// struct of elf header
struct elf32_ehdr {
	unsigned char e_ident[16];
	elf32_half e_type; //2, 可执行文件
	elf32_half e_machine; //40, ARM中运行的程序
	elf32_word e_version;
	elf32_addr e_entry; //程序入口
	elf32_off  e_phoff; //program header
	elf32_off  e_shoff;
	elf32_word e_flags;
	elf32_half e_ehsize;
	elf32_half e_phentsize; //size of per program header
	elf32_half e_phnum; //num of program header
	elf32_half e_shentsize;
	elf32_half e_shnum;
	elf32_half eshstrndx;
};

// struct of program header
struct elf32_phdr {
	elf32_word p_type; // 1, 代表该segment为代码或数据， 需要载入mem
	elf32_off  p_offset; // segment's offset
	elf32_addr p_vaddr; // segment's address in mem
	elf32_addr p_paddr;
	elf32_word p_filesz; //size of segment
	elf32_word p_memsz;
	elf32_word p_flags;
	elf32_word p_align;
};

int exec(unsigned int entry)
{
	asm volatile (
		"stmfd sp!, {lr}\n\t"
		"mov lr, pc\n\t"
		"mov pc, r0\n\t"
		"ldmfd sp!, {lr}\n\t"
//		:::"lr"
	);
	return 0;
}

void call_app(char *app_name)
{
	struct inode *node;
	struct elf32_ehdr *ehdr;
	struct elf32_phdr *phdr;
	int i;
	int pos;
	int dpos;
	void *elfbuf;

	node = fs_type[ROMFS]->namei(fs_type[ROMFS], app_name);
	if(!node) {
		display("\t>find file fail\n");
		return;
	}

	if(!(elfbuf = kmalloc(node->dsize))) {
		display("\t>kmalloc mem for elf fail\n");
		kfree(node); node = NULL;
		return;
	}

	if(fs_type[ROMFS]->device->dout(fs_type[ROMFS]->device, elfbuf, fs_type[ROMFS]->get_daddr(node), node->dsize)) {
		display("\t>dout fail\n");
		kfree(node); node = NULL;
		kfree(elfbuf); elfbuf = NULL;
		return;
		
	}

	ehdr = (struct elf32_ehdr *)elfbuf;
	phdr = (struct elf32_phdr *)((char *)elfbuf + ehdr->e_phoff);

	for(i = 0; i < ehdr->e_phnum; i++) {
		if(1 == phdr->p_type) {
			memcpy((void *)phdr->p_vaddr, (void *)((char *)elfbuf + phdr->p_offset), phdr->p_filesz);
		}
		phdr++;
	}

	kfree(node); node = NULL;
	kfree(elfbuf); elfbuf = NULL;

	exec(ehdr->e_entry);

	display("app returned\n");
}
