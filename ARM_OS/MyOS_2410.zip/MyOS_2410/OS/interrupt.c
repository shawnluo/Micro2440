// Version 0.0.0.1
// Author Liyong-Zou
// Create Date 2012-07-25
// Init file

/* Date 2012-07-25
/* Author Liyong-Zou
/* Init function enable_irq irq_handler
*/

#include "interrupt.h"
#include "MyOS.h"
#include "mmu.h"

#define SRCPND		(PHYSICAL_SRCPND + VIR_IO_ADDR_OFFSET)
#define INTMOD		(PHYSICAL_INTMOD + VIR_IO_ADDR_OFFSET)
#define INTMSK		(PHYSICAL_INTMSK + VIR_IO_ADDR_OFFSET)
#define PRIORITY	(PHYSICAL_PRIORITY + VIR_IO_ADDR_OFFSET)
#define INTPND		(PHYSICAL_INTPND + VIR_IO_ADDR_OFFSET)
#define INTOFFSET	(PHYSICAL_INTOFFSET + VIR_IO_ADDR_OFFSET)
#define SUBSRCPND	(PHYSICAL_SUBSRCPND + VIR_IO_ADDR_OFFSET)
#define INTSUBMSK	(PHYSICAL_INTSUBMSK + VIR_IO_ADDR_OFFSET)

void enable_irq(void)
{
	asm volatile (
		"mrs r4, cpsr\n"
		"bic r4, r4, #0x80\n"
		"msr cpsr, r4\n"
		:
		:
		: "r4"
	);
}

void disable_irq(void)
{
	asm volatile (
		"mrs r4, cpsr\n"
		"orr r4, r4, #0x80\n"
		"msr cpsr, r4\n"
		:
		:
		: "r4"
	);
}

void unmask_int(unsigned int offset)
{
	char szMsg[128];
	sprintf_s(szMsg, 128, "\t>unmask offset: %d\n", offset);
	display(szMsg);
	*(volatile unsigned int *)INTMSK &= ~(1 << offset);
}

void irq_handler(void)
{
	char szMsg[128];
	unsigned int tmp = (1 << (*(volatile unsigned int *)INTOFFSET));
	sprintf_s(szMsg, 128, "offset: %d\t", *(volatile unsigned int *)INTOFFSET);
	display(szMsg);

	*(volatile unsigned int *)SRCPND |= tmp;
	*(volatile unsigned int *)INTPND |= tmp;

	enable_irq();

	sprintf_s(szMsg, 128, "interrupt occured\n");
	display(szMsg);
}
