// Version 0.0.0.1
// Author Liyong-Zou
// Create Date 2012-07-19
// Init file

/* Date 2012-07-19
/* Author Liyong-Zou
/* Add function init_mmu
*/
#ifndef _MMU_H
#define _MMU_H

#define VIRTUAL_VECTOR_ADDR		(0x00000000)
#define PHYSICAL_MEM_ADDR		(0x30000000)
#define VIRTUAL_MEM_ADDR		(0x30000000)
#define MEM_MAP_SIZE			(0x800000)
#define PHYSICAL_IO_ADDR		(0x48000000)
#define VIRTUAL_IO_ADDR			(0xc8000000)
#define IO_MAP_SIZE			(0x18000000)

#define VIR_VECTOR_ADDR_OFFSET		(VIRTUAL_VECTOR_ADDR - PHYSICAL_MEM_ADDR)
#define VIR_IO_ADDR_OFFSET		(VIRTUAL_IO_ADDR - PHYSICAL_IO_ADDR)

extern void init_mmu(void);

extern void remap_l1(unsigned int paddr, unsigned int vaddr, int size);

#endif
