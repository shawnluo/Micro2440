
#include "test.h"
#include "memory.h"
#include "storage.h"
#include "MyOS.h"
#include "fs.h"
#include "exec.h"
#include "proc.h"

static void test_slab(void)
{
	struct kmem_cache cache;
	unsigned int size = 0x10000;
	void *address1 = NULL;
	void *address2 = NULL;
	char msg[128];

	if(!kmem_cache_create(&cache, size, 0))
	{
		display("\t>kmem_cache_create fail\n");
		return;
	}

	do {
		address1 = kmem_cache_alloc(&cache);
		if(address1) {
			sprintf_s(msg, 128, "\t>alloc slab address: %x\n", address1);
			display(msg);
		} else {
			display("\t>kmem_cache_alloc fail\n");
			kmem_cache_destory(&cache);
			if(!kmem_cache_create(&cache, size, 0))
			{
				display("\t>kmem_cache_create fail\n");
				return;
			}
			address1 = kmem_cache_alloc(&cache);
			if(address1) {
				sprintf_s(msg, 128, "\t>alloc slab address: %x\n", address1);
				display(msg);
			} else {
				display("\t>kmem_cache_alloc fail\n");
			}
			return;
		}
/*
		address2 = kmem_cache_alloc(&cache);
		if(address2) {
			sprintf_s(msg, 128, "\t>alloc slab address: %x\n", address2);
			display(msg);
		} else {
			display("\t>kmem_cache_alloc fail\n");
		}
	
		//kmem_cache_free(address1);
		kmem_cache_free(address2);
		kmem_cache_destory(&cache);
		return;*/
	} while(1);
}

/*************************************test_kmalloc***********************************************/
static void test_kmalloc(void)
{
	unsigned int size = 4096;
	void *address1 = NULL;
	void *address2 = NULL;
	char msg[128];

	do {
		address1 = kmalloc(size);
		if(address1) {
			sprintf_s(msg, 128, "\t>kmalloc mem address: %x\n", address1);
			display(msg);
		} else {
			display("\t>kmalloc fail\n");
			return;
		}/*
		if(address1) {
			kfree(address1);
			address1 = NULL;
		}

		address2 = kmalloc(size);
		if(address2) {
			sprintf_s(msg, 128, "\t>kmalloc mem address: %x\n", address2);
			display(msg);
		} else {
			display("\t>kmalloc fail\n");
		}

		
		if(address1) {
			kfree(address1);
			address1 = NULL;
		}
		if(address2) {
			kfree(address2);
			address2 = NULL;
		}*/
	} while(1);
}

/**************************************test ramdisk*******************************************************/
void test_ramdisk(void)
{
	char *rbuff = kmalloc(128);
	storage[RAMDISK]->dout(storage[RAMDISK], rbuff, 0, 127);
	rbuff[127] = '\0';
	display(rbuff);
}

/**************************************test file system***************************************************/
void test_fs(void)
{
	struct inode *node = NULL;
	char buf[128];

	node = fs_type[ROMFS]->namei(fs_type[ROMFS], /*"not exit"*/ /*"file.txt"*/ /*"dir/file.txt"*/ "dir/file2.txt");
	if(!node) {
		display("\t>namei fail\n");
		return;
	}
	memset(buf, 0, 128);
	fs_type[ROMFS]->device->dout(fs_type[ROMFS]->device, buf, fs_type[ROMFS]->get_daddr(node), node->dsize);

	display(buf);
}

/**************************************test exec***************************************************/
void test_exec(void)
{
	call_app("helloWorld" /*"main"*/ /*"helloworld"*/);
	display("test_exec returned\n");
}

/**************************************test task***************************************************/
void delay(void)
{
	volatile unsigned int time = 0xffff;
	while(time--);
}

int process(void *p)
{
	char msg[128];
	sprintf_s(msg, 128, "Process %d for test\n", (unsigned int)p);
	while(1) {
		delay();
		display(msg);
	}
	return 0;
}

void test_task(void)
{
	do_fork(process, (void *)0x00);
	do_fork(process, (void *)0x01);

	while(1) {
		delay();
		display("original process\n");
	}
}

void test(void)
{
	//test_slab();

	//test_kmalloc();

	//test_ramdisk();

	//test_fs();

	//test_exec();

	test_task();
}
