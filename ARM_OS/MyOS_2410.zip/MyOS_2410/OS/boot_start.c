// Version 0.0.0.1
// Author Liyong-Zou
// Create date 2012-01-21
// Init File

/* Date 2012-07-21
/* Author Liyong-Zou
/* Add function boot_start
*/

#include "boot_start.h"
#include "MyOS.h"

void boot_start(void)
{
	display("boot_start\n");
}
