// Version 0.0.0.1
// Author Liyong-Zou
// Create Date 2012-07-25
// Init file

/* Date 2012-07-25
/* Author Liyong-Zou
/* Add function enable_irq, umask_int, irq_handler
*/
#ifndef _INTERRUPT_H
#define _INTERRUPT_H

#define PHYSICAL_SRCPND		(0x4a000000)
#define PHYSICAL_INTMOD		(0x4a000004)
#define PHYSICAL_INTMSK		(0x4a000008)
#define PHYSICAL_PRIORITY	(0x4a00000c)
#define PHYSICAL_INTPND		(0x4a000010)
#define PHYSICAL_INTOFFSET	(0x4a000014)
#define PHYSICAL_SUBSRCPND	(0x4a000018)
#define PHYSICAL_INTSUBMSK	(0x4a00001c)

extern void enable_irq(void);
extern void disable_irq(void);
extern void unmask_int(unsigned int offset);
extern void irq_handler(void);

#endif
