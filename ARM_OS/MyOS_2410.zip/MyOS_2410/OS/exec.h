#ifndef _EXEC_H
#define _EXEC_H

extern void call_app(char *app_name);

#endif
