

#ifndef _STRING_H
#define _STRING_H

inline int strcmp(const char *cs, const char *ct)
{
	register signed char res;
	while(1) {
		if((0 != (res = *cs - *ct++)) || '\0' == *cs++) break;
	}

	return res;
}

inline void *memset(void *s, int c, unsigned int count)
{
	char * xs = (char *)s;
	while(count--) {
		*xs++ = c;
	}

	return s;
}

inline char *strcpy(char *dest, const char *src)
{
	char *tmp = dest;
	while('\0' != (*tmp++ = *src++));
	return dest;
}

inline char *strncpy(char *dest, const char *src, unsigned int count)
{
	char *tmp = dest;
	while((count--) && ('\0' != (*tmp++ = *src++)));
	return dest;
}

inline unsigned int strlen(const char *s)
{
	const char *sc = s;
	while(*sc++);
	return --sc - s;
}

inline char *strchr(const char *s, int c)
{
	for(; '\0' != *s; s++) {
		if(*s == c) return (char *)s;
	}
	return (char *)0;
}

#endif
