#include "syscall.h"

#define __NR_SYSCALL_BASE		0x0
#define __NR_TEST			(__NR_SYSCALL_BASE + 0)
#define __NR_SYS_CALL			(__NR_SYSCALL_BASE + 1)
// num -> 系统调用编号; pnum -> num of param; parry -> list of param; ret -> return value
#define SYSCALL(num, pnum, parray, ret)	do{\
				asm volatile ( \
				  "stmfd sp!, {%3}\n" \
				  "stmfd sp!, {%2}\n" \
				  "sub sp, sp, #4\n" \
				  "SWI %1\n" \
				  "ldmfd sp!, {%0}\n" \
				  "add sp, sp, #8\n" \
				  :"=r"(ret) \
				  :"i" (num), "r" (pnum), "r" (parray) \
				 ); \
				}while(0)

int test_syscall(void)
{
	int arry[5] = {1, 2, 3, 4, 5};
	int ret = 0;
	SYSCALL(__NR_SYSCALL_BASE, 5, arry, ret);

//	char msg[128];
//	sprintf_s(msg, 128, "\t>ret = %d\n", ret);
}

