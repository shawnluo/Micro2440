#include "syscall.h"

int main(void)
{
	test_syscall();
}
