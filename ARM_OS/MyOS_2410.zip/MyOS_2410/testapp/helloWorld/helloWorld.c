#define UFCON0 ((volatile unsigned int *)(0xd0000020))

int main()
{
	char *msg = "Hello World\n";

	while(*msg) {
		*UFCON0 = *msg++;
	}

	return 0;
}
